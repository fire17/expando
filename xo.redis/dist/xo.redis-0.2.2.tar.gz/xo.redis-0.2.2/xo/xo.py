from expando import Expando
# from expando import Expando
xo = Expando()